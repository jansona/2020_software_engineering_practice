package software.practice.distribution;

import org.junit.jupiter.api.Test;
import software.practice.distribution.entity.Deal;
import software.practice.distribution.service.AddDealService;

/**
 * @author ：Chang Jiaxin
 * @date ：Created in 2020/4/15 下午 12:17
 * @description ：
 */
public class AddDealTests {
    @Test
    public void add(){
        AddDealService service = new AddDealService();
        Deal deal = new Deal();
        deal.setDealContent("aaa");
        deal.setDealId(1);
        deal.setDealUser(1);
        service.addDeal(deal);
    }
}
