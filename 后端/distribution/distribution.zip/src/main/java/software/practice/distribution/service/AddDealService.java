package software.practice.distribution.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import software.practice.distribution.entity.Deal;
import software.practice.distribution.mapper.DealMapper;

/**
 * @author ：Chang Jiaxin
 * @date ：Created in 2020/4/15 上午 11:14
 * @description ： 申请特殊处理
 */
@Service
public class AddDealService {
    @Autowired
    DealMapper dealMapper;

    public boolean addDeal(Deal deal){
        return dealMapper.insert(deal) == 1;
    }
}
